[![GitHub license](https://img.shields.io/github/license/Shalucik/operator-roles)](https://github.com/Shalucik/operator-roles/blob/main/LICENSE)
[![GitHub release](https://img.shields.io/github/release/Shalucik/operator-roles.svg)](https://github.com/Shalucik/operator-roles/releases)

# operator-roles

